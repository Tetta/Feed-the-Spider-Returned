//
//  CHInstanceProvider+AFNetworking.h
//  CrashHunter
//
//  Created by Stas Kochkin on 15/12/2016.
//  Copyright © 2016 Appodeal. All rights reserved.
//

#import "CHInstanceProvider.h"
#import <AFNetworking/AFNetworking.h>


@interface CHInstanceProvider (AFNetworking)

- (AFHTTPSessionManager *)sessionManagerWithBaseURL:(NSURL *)url;
- (AFJSONRequestSerializer *)requestSerializer;
- (AFJSONResponseSerializer *)responseSerializer;

@end
