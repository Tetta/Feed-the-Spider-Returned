//
//  CHHandler.h
//  CrashHunter
//
//  Created by Stas Kochkin on 18/01/2017.
//  Copyright © 2017 Appodeal. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CHHandler : NSObject

@property (nonatomic, assign, readonly) NSInteger reportsCount;
@property (nonatomic, assign, readonly) NSArray * allReports;
@property (nonatomic, strong, readwrite) NSDictionary * customInfo;

- (void)install;
- (void)handleException:(NSException *)exception;
- (void)deleteReports;

@end
