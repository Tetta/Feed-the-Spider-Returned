//
//  CHPlatformInfo.h
//  CrashHunter
//
//  Created by Lozhkin Ilya on 1/24/17.
//  Copyright © 2017 Appodeal. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <KSCrash/KSCrash.h>

void ch_populatePlatformInfo(const KSCrashReportWriter * writer);

@interface CHPlatformInfo : NSObject

@end
