//
//  CHInstanceProvider.h
//  CrashHunter
//
//  Created by Stas Kochkin on 15/12/2016.
//  Copyright © 2016 Appodeal. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CHInstanceProvider : NSObject

+ (id)sharedProvider;

@end
