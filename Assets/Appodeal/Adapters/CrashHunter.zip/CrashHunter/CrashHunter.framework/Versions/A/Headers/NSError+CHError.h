//
//  NSError+CHError.h
//  CrashHunter
//
//  Created by Stas Kochkin on 14/12/2016.
//  Copyright © 2016 Appodeal. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, CHErrorCode) {
    CHErrorRetryTimeNotExpired = 444,
    CHErrorNetwork,
    CHEmptyReportStore
};

@interface NSError (CHError)

+ (NSError *)ch_errorWithCode:(CHErrorCode)code description:(NSString *)description;
- (NSError *)ch_wrapWithCode:(CHErrorCode)code;

@end
